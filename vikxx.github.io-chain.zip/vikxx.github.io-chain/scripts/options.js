var vblog={
        login:'vik',
		replieLink:'free',
		followTag:'ru--otkrytyij-kod',

};	
