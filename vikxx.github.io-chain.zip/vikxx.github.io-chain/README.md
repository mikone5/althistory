
# Демо https://chain.cf

Блог с хостингом статики на github и базой данный в блокчейне golos.io

Используйте options.js для настроек
